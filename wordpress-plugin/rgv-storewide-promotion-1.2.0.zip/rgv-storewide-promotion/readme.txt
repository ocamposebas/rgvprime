=== RGV Storewide Promotion ===
Contributors: rgvprime
Tags: woocommerce, promotion, sale, countdown, product discount
Requires at least: 6.5
Requires PHP: 7.4
Stable tag: 1.2.0
License: GPLv2 or later

Schedules a WooCommerce storewide or single-product discount and exposes a synchronized countdown announcement.

== Description ==

RGV Storewide Promotion keeps pricing and promotion messaging on the same schedule.

* Apply a percentage discount to simple products and variations without rewriting saved product prices.
* Choose between an entire-store campaign and one specific product, including all of its variations.
* Search for the target product directly from the promotion settings.
* Set an optional start time and a required end time in the WordPress site timezone.
* Publish campaign data through /wp-json/rgv-promotion/v1/current for a headless storefront.
* Optionally show a clean countdown banner on the native WordPress storefront.
* Send the banner button directly to the selected product when no custom URL is entered.
* Restore regular pricing automatically when the campaign expires or is paused.
* Store the campaign percentage as private order metadata for operational traceability.

The discount is calculated from each product's current effective price. Existing product sales may therefore receive the campaign discount as well.

== Installation ==

1. Upload the plugin ZIP in WordPress under Plugins > Add New Plugin > Upload Plugin.
2. Activate RGV Storewide Promotion.
3. Open WooCommerce > Promotions.
4. Choose whether the discount applies to the entire store or one product.
5. Configure the discount, announcement, schedule and optional destination URL.
6. Enable the campaign and save.

== Changelog ==

= 1.2.0 =
* Added single-product promotions with WooCommerce product search.
* Applied product promotions to every variation of the selected product.
* Added automatic banner links to the selected product.
* Exposed the campaign scope and selected product through the storefront endpoint.

= 1.1.0 =
* Redesigned the offer banner around the RGVPRIME storefront structure.
* Added a larger campaign headline and countdown tiles for clearer mobile visibility.
* Kept pricing, campaign expiration, and the public storefront message synchronized.

= 1.0.0 =
* Initial release.
* Scheduled storewide product pricing.
* Public headless campaign endpoint.
* Native storefront countdown.
* HPOS compatibility declaration and order metadata.
