(function () {
  "use strict";

  function initializePromotionTarget() {
    var scope = document.querySelector("[data-rgv-promotion-scope]");
    var target = document.querySelector("[data-rgv-product-target]");

    if (!scope || !target) return;

    var product = target.querySelector('select[name="product_id"]');

    function updateTargetVisibility() {
      var isProduct = scope.value === "product";
      target.hidden = !isProduct;

      if (product) {
        product.required = isProduct;
      }
    }

    scope.addEventListener("change", updateTargetVisibility);
    updateTargetVisibility();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initializePromotionTarget);
  } else {
    initializePromotionTarget();
  }
})();
