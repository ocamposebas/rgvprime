=== RGV ORBIT Payments Checkout ===
Contributors: rgvprime
Requires at least: 6.4
Requires PHP: 7.4
Requires Plugins: woocommerce
Stable tag: 1.2.1

Standalone embedded credit and debit card checkout branded as ORBIT Payments. It does
not replace or modify the RGV Zelle Checkout plugin.

== Setup ==

Add the four processor credentials as private environment variables on the
WordPress service/container. Start with Sandbox:

WOMPI_PUBLIC_KEY=pub_test_REPLACE_ME
WOMPI_PRIVATE_KEY=prv_test_REPLACE_ME
WOMPI_INTEGRITY_SECRET=test_integrity_REPLACE_ME
WOMPI_EVENTS_SECRET=test_events_REPLACE_ME

The plugin automatically obtains the currently valid official Colombian TRM
from the Superfinanciera dataset on datos.gov.co. It caches the result for six
hours and can use its last successful result for up to three days if the service
has a temporary outage. Checkout fails closed if no safe rate is available.

WOMPI_COP_PER_USD is optional. Set it only when a deliberate manual rate must
override the official TRM.

Restart or redeploy the WordPress service after saving the variables. Do not add
these values to the Astro/frontend service. Constants in wp-config.php remain a
supported fallback, but are not required.

Configure the matching environment event URL in the processor dashboard:

https://YOUR-WORDPRESS-DOMAIN/wp-json/rgv/v1/orbit-card-events

The form stays embedded in the RGV storefront. Card number and CVC are JWE
encrypted in the browser and sent directly to the card processor. Only the
resulting token is submitted to the storefront and WordPress servers.

Version 1.2.0 uses Wompi's standard direct card transaction flow. It does not
request 3D Secure, open a hosted checkout, or render an issuer challenge. Wompi
charges in COP while the storefront and WooCommerce retain the USD order total.
Wompi's current browser fingerprinting
library supplies silent session and device identifiers for antifraud analysis
when available.

== Changelog ==

= 1.2.1 =
* Activates no-minimum standard shipping through November 8, 2026 at 11:00 p.m. Colombia time, then restores the $200 threshold automatically.

= 1.2.0 =
* Atomically reserves product stock before submitting a card charge.
* Releases the reservation if checkout fails before payment submission.

= 1.1.4 =
* Saves the $45 shipping line as `UPS 45` so Pirate Ship can distinguish it from standard UPS shipping.

= 1.1.3 =
* Rounds the converted charge to a whole Colombian peso before creating a card transaction.
* Guarantees that Wompi receives a card amount divisible by 100 minor units.

= 1.1.2 =
* Removes the currency/security footer from the embedded card form.
* Removes the installment selector and always submits a single payment.

= 1.1.1 =
* Activates the embedded Wompi card option in the storefront.
* Stops requesting 3D Secure and removes the bank challenge iframe.
* Keeps a compact COP disclosure next to the encrypted card form.
* Sends Wompi's silent session and device identifiers when fingerprinting is available.

= 1.1.0 =
* Enables Wompi 3D Secure for production card transactions.
* Sends validated browser information required for issuer authentication.
* Supports frictionless authentication and visible bank challenge iframes.
* Polls securely until the transaction reaches a final state while preserving webhook verification.

= 1.0.4 =
* Raises the ORBIT Payments maximum order total from $150 to $600 USD.

= 1.0.3 =
* Activates the production checkout display under the ORBIT Payments name.

= 1.0.2 =
* Initially limited embedded ORBIT card checkout to orders of $150.00 USD or less.

= 1.0.1 =
* Automatically obtains and safely caches the official Colombian TRM.
* Makes the manual USD-to-COP environment variable optional.

= 1.0.0 =
* Adds standalone embedded ORBIT card fields and encrypted tokenization.
* Creates authoritative WooCommerce card orders.
* Verifies status server-side and processes signed transaction events.
* Prevents blind retries after uncertain responses.
