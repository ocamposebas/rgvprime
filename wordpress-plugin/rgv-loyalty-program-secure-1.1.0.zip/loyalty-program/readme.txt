=== RGV Loyalty Program ===
Contributors: rgvprime
Tags: woocommerce, loyalty, points, rewards, store credit
Requires at least: 6.5
Requires PHP: 7.4
Requires Plugins: woocommerce
Stable tag: 1.1.0

A hardened WooCommerce loyalty program for the authenticated RGV customer portal.

== Description ==

Default program:

* One point per eligible currency unit spent on merchandise after discounts.
* Shipping and fees never earn points.
* 1,000 points unlocks redemption.
* Each 1,000 points can be exchanged for 25 units of store credit.
* Points are awarded at Completed, or at Processing when enabled.
* Partial refunds recalculate only refunded merchandise.
* Cancelled, failed and fully refunded orders reconcile their credited points to zero.
* Rewards generate an email-restricted, single-use, individual-use coupon.
* Coupon expiration is configurable and defaults to 90 days.

== Security protections ==

* Per-customer database locking prevents simultaneous double redemptions.
* Database transactions keep balance, history, coupon and order metadata consistent.
* Optional Idempotency-Key support safely handles repeated API requests.
* Negative balances are preserved when a customer used a reward before refunding its source purchase.
* Unused active reward coupons are revoked and converted back to points before a reversal.
* Used reward coupons are restored only when the order that consumed them is cancelled, failed or fully refunded.
* Restored and revoked coupons are expired and permanently rejected by an additional validation filter.
* Loyalty coupons are limited to their account owner and billing email.
* A negative loyalty balance blocks all reward redemptions and reward coupon usage.
* Redemption requests are rate limited.
* All administrative adjustments require WooCommerce management permission and a valid nonce.
* WooCommerce HPOS compatibility is declared and all order access uses WooCommerce CRUD objects.

== Headless portal requirement ==

The plugin expects the existing RGV Portal authentication route at `/rgv-portal/v1/me` or its helper functions.
The `x-rgv-portal-secret` header must be sent only from your Astro server. Never expose that secret in browser JavaScript.

The redemption endpoint is:

`POST /wp-json/rgv-portal/v1/loyalty/redeem`

Headers:

* `Authorization: Bearer ...`
* `x-rgv-portal-secret: ...`
* Optional: `Idempotency-Key: unique-request-id`

Body:

`{"points":1000}`

Omit `points` to redeem the maximum currently available whole reward amount.

== Upgrade notice ==

Version 1.1.0 keeps the existing balance, history, order and coupon metadata from version 1.0.0.
Because version 1.0.0 prevented negative balances, historical abuse that happened before this update cannot be inferred automatically. Review suspicious customers manually after activation.

== Changelog ==

= 1.1.0 =

* Rebuilt balance mutations with signed balances, locks and transactions.
* Added idempotent and rate-limited redemptions.
* Replaced additive refund logic with idempotent order-point reconciliation.
* Added merchandise-only partial refund calculations.
* Added automatic revocation of unused rewards during reversals.
* Added permanent invalidation and safe restoration of consumed rewards.
* Added owner and negative-balance coupon validation.
* Added HPOS declaration, plugin requirements and WooCommerce dependency header.
* Added customer pagination and negative-balance visibility in the administrator.
* Repacked the plugin with portable ZIP paths.
