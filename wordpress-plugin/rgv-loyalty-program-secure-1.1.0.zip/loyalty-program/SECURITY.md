# RGV Loyalty Program security notes

1. Keep the portal API secret on the Astro server only. Do not put it in `PUBLIC_*` environment variables or client-side JavaScript.
2. Use HTTPS for WordPress and the storefront.
3. Leave WooCommerce order webhooks and status transitions protected by administrator permissions.
4. A negative points balance is intentional. Do not reset it unless a reviewed manual adjustment is warranted.
5. Review WooCommerce logs with source `rgv-loyalty` after any database or coupon error.
6. Test upgrades on staging and take a database backup before replacing the plugin in production.
