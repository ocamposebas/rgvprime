<?php
/**
 * Plugin Name: RGV Loyalty Program
 * Description: Secure points and store-credit rewards for WooCommerce customers.
 * Version: 1.1.0
 * Author: RGVPRIME LLC
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * Text Domain: rgv-loyalty
 */

defined('ABSPATH') || exit;

final class RGV_Loyalty_Program {
    const VERSION = '1.1.0';
    const OPTION = 'rgv_loyalty_settings';
    const VERSION_OPTION = 'rgv_loyalty_version';

    const BALANCE_META = '_rgv_loyalty_points';
    const HISTORY_META = '_rgv_loyalty_history';
    const IDEMPOTENCY_META = '_rgv_loyalty_idempotency';

    // Kept for backwards compatibility with version 1.0.0.
    const ORDER_POINTS_META = '_rgv_loyalty_points_awarded';

    const REFUND_POINTS_META = '_rgv_loyalty_points_reversed';
    const COUPON_OWNER_META = '_rgv_loyalty_customer_id';
    const COUPON_POINTS_META = '_rgv_loyalty_points_spent';
    const COUPON_STATUS_META = '_rgv_loyalty_status';
    const COUPON_REDEMPTION_META = '_rgv_loyalty_redemption_id';
    const COUPON_USED_ORDER_META = '_rgv_loyalty_used_order_id';
    const COUPON_RESTORED_ORDER_META = '_rgv_loyalty_restored_order_id';
    const COUPON_REVOKED_REASON_META = '_rgv_loyalty_revoked_reason';
    const COUPON_CREATED_META = '_rgv_loyalty_created_at';

    const COUPON_STATUS_ACTIVE = 'active';
    const COUPON_STATUS_USED = 'used';
    const COUPON_STATUS_REVOKED = 'revoked';
    const COUPON_STATUS_RESTORED = 'restored';

    /** @var self|null */
    private static $instance = null;

    /** @var array<string,int> */
    private $request_users = [];

    /** @var array<int,bool> */
    private $transaction_user_ids = [];

    /** @var array<int,bool> */
    private $transaction_post_ids = [];

    public static function boot() {
        if (!self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public static function activate() {
        if (!get_option(self::OPTION, null)) {
            add_option(self::OPTION, [
                'points_per_dollar' => 1,
                'minimum_points' => 1000,
                'points_per_reward' => 1000,
                'reward_value' => 25,
                'award_processing' => 0,
                'coupon_expiry_days' => 90,
            ], '', false);
        }

        update_option(self::VERSION_OPTION, self::VERSION, false);
    }

    private function __construct() {
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_notices', [$this, 'woocommerce_notice']);
        add_action('admin_post_rgv_loyalty_adjust', [$this, 'admin_adjust']);

        add_action('woocommerce_order_status_changed', [$this, 'handle_order_status_changed'], 20, 4);
        add_action('woocommerce_order_refunded', [$this, 'handle_order_refunded'], 20, 2);

        add_action('rest_api_init', [$this, 'register_routes']);
        add_filter('rest_post_dispatch', [$this, 'add_loyalty_to_portal_response'], 10, 3);

        add_filter('manage_users_columns', [$this, 'user_column']);
        add_filter('manage_users_custom_column', [$this, 'user_column_value'], 10, 3);

        add_filter('woocommerce_coupon_is_valid', [$this, 'validate_loyalty_coupon'], 20, 3);

        $this->maybe_upgrade();
    }

    private function maybe_upgrade() {
        if (get_option(self::VERSION_OPTION) !== self::VERSION) {
            update_option(self::VERSION_OPTION, self::VERSION, false);
        }
    }

    public function woocommerce_notice() {
        if (!current_user_can('activate_plugins') || class_exists('WooCommerce')) {
            return;
        }

        echo '<div class="notice notice-error"><p>';
        echo esc_html__('RGV Loyalty Program requires WooCommerce to be installed and active.', 'rgv-loyalty');
        echo '</p></div>';
    }

    public function settings() {
        return wp_parse_args(get_option(self::OPTION, []), [
            'points_per_dollar' => 1,
            'minimum_points' => 1000,
            'points_per_reward' => 1000,
            'reward_value' => 25,
            'award_processing' => 0,
            'coupon_expiry_days' => 90,
        ]);
    }

    public function sanitize_settings($value) {
        $value = is_array($value) ? $value : [];
        $block = min(100000000, max(1, absint($value['points_per_reward'] ?? 1000)));
        $minimum = min(100000000, max($block, absint($value['minimum_points'] ?? 1000)));

        // A redeem threshold that is not a whole reward block can never be reached cleanly.
        $minimum = (int) (ceil($minimum / $block) * $block);

        return [
            'points_per_dollar' => min(1000, max(0.0001, (float) ($value['points_per_dollar'] ?? 1))),
            'minimum_points' => $minimum,
            'points_per_reward' => $block,
            'reward_value' => min(100000, max(0.01, (float) ($value['reward_value'] ?? 25))),
            'award_processing' => empty($value['award_processing']) ? 0 : 1,
            'coupon_expiry_days' => min(3650, max(1, absint($value['coupon_expiry_days'] ?? 90))),
        ];
    }

    public function register_settings() {
        register_setting('rgv_loyalty', self::OPTION, [
            'type' => 'array',
            'sanitize_callback' => [$this, 'sanitize_settings'],
            'default' => $this->settings(),
        ]);
    }

    /**
     * Balances are intentionally signed. A negative balance is loyalty debt caused by
     * refunds, chargebacks, cancellations or manual fraud adjustments after rewards were used.
     */
    public function get_balance($user_id) {
        $value = get_user_meta(absint($user_id), self::BALANCE_META, true);
        return is_numeric($value) ? (int) $value : 0;
    }

    private function set_balance_unlocked($user_id, $balance) {
        $user_id = absint($user_id);
        $balance = (int) $balance;
        $this->transaction_user_ids[$user_id] = true;

        update_user_meta($user_id, self::BALANCE_META, $balance);
        wp_cache_delete($user_id, 'user_meta');

        $stored = get_user_meta($user_id, self::BALANCE_META, true);
        if (!is_numeric($stored) || (int) $stored !== $balance) {
            throw new RuntimeException('Unable to persist the loyalty balance.');
        }
    }

    private function history($user_id) {
        $history = get_user_meta(absint($user_id), self::HISTORY_META, true);
        return is_array($history) ? $history : [];
    }

    private function transaction_unlocked($user_id, $points, $type, $description, $reference = '', $allow_negative = true) {
        $user_id = absint($user_id);
        $points = (int) $points;
        $before = $this->get_balance($user_id);
        $after = $before + $points;

        if (!$allow_negative && $after < 0) {
            return new WP_Error(
                'loyalty_insufficient_points',
                __('Your points balance changed. Refresh and try again.', 'rgv-loyalty'),
                ['status' => 409]
            );
        }

        if ($points === 0) {
            return [
                'before' => $before,
                'after' => $before,
                'applied' => 0,
            ];
        }

        $this->set_balance_unlocked($user_id, $after);

        $history = $this->history($user_id);
        array_unshift($history, [
            'id' => wp_generate_uuid4(),
            'date' => current_time('mysql', true),
            'points' => $points,
            'balance' => $after,
            'type' => sanitize_key($type),
            'description' => sanitize_text_field(wp_strip_all_tags((string) $description)),
            'reference' => sanitize_text_field((string) $reference),
        ]);

        $this->transaction_user_ids[$user_id] = true;
        $history_updated = update_user_meta($user_id, self::HISTORY_META, array_slice($history, 0, 500));
        if ($history_updated === false) {
            throw new RuntimeException('Unable to persist the loyalty history.');
        }
        wp_cache_delete($user_id, 'user_meta');

        return [
            'before' => $before,
            'after' => $after,
            'applied' => $points,
        ];
    }

    private function lock_name($user_id) {
        return substr('rgvl_' . get_current_blog_id() . '_' . absint($user_id), 0, 64);
    }

    /**
     * Serializes all mutations for one customer. MySQL named locks work across PHP workers.
     * An atomic WordPress option is used only when the database does not support GET_LOCK().
     */
    private function with_user_lock($user_id, $callback, $timeout = 8) {
        global $wpdb;

        $user_id = absint($user_id);
        if (!$user_id) {
            return new WP_Error('loyalty_customer', __('Customer account not found.', 'rgv-loyalty'), ['status' => 404]);
        }

        $name = $this->lock_name($user_id);
        $mysql_lock = $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, %d)', $name, absint($timeout)));
        $fallback_token = '';
        $fallback_option = '';

        if ((string) $mysql_lock !== '1') {
            if ($mysql_lock !== null) {
                return new WP_Error(
                    'loyalty_busy',
                    __('Your rewards account is busy. Try again in a moment.', 'rgv-loyalty'),
                    ['status' => 409]
                );
            }

            $fallback_option = 'rgvl_lock_' . get_current_blog_id() . '_' . $user_id;
            $fallback_token = wp_generate_uuid4();
            $existing = get_option($fallback_option, []);

            if (is_array($existing) && !empty($existing['time']) && (time() - absint($existing['time'])) > 30) {
                delete_option($fallback_option);
            }

            if (!add_option($fallback_option, ['token' => $fallback_token, 'time' => time()], '', false)) {
                return new WP_Error(
                    'loyalty_busy',
                    __('Your rewards account is busy. Try again in a moment.', 'rgv-loyalty'),
                    ['status' => 409]
                );
            }
        }

        try {
            wp_cache_delete($user_id, 'user_meta');
            return call_user_func($callback);
        } finally {
            if ((string) $mysql_lock === '1') {
                $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $name));
            } elseif ($fallback_option && $fallback_token) {
                $stored = get_option($fallback_option, []);
                if (is_array($stored) && hash_equals($fallback_token, (string) ($stored['token'] ?? ''))) {
                    delete_option($fallback_option);
                }
            }
        }
    }

    /**
     * Groups user-meta, coupon-meta and order-meta mutations in one database transaction.
     */
    private function db_transaction($callback) {
        global $wpdb;

        $this->transaction_user_ids = [];
        $this->transaction_post_ids = [];

        if ($wpdb->query('START TRANSACTION') === false) {
            $this->log('error', 'Unable to start a loyalty database transaction.');
            return new WP_Error(
                'loyalty_transaction_unavailable',
                __('The rewards system could not start a safe transaction. No changes were applied.', 'rgv-loyalty'),
                ['status' => 503]
            );
        }

        try {
            $result = call_user_func($callback);

            if (is_wp_error($result)) {
                $wpdb->query('ROLLBACK');
                $this->clear_rolled_back_caches();
                return $result;
            }

            if ($wpdb->query('COMMIT') === false) {
                throw new RuntimeException('Unable to commit loyalty transaction.');
            }

            $this->transaction_user_ids = [];
            $this->transaction_post_ids = [];
            return $result;
        } catch (Throwable $error) {
            $wpdb->query('ROLLBACK');
            $this->clear_rolled_back_caches();
            $this->log('error', 'Loyalty database transaction failed.', [
                'exception' => $error->getMessage(),
            ]);

            return new WP_Error(
                'loyalty_transaction_failed',
                __('The rewards transaction could not be completed safely. No changes were applied.', 'rgv-loyalty'),
                ['status' => 500]
            );
        }
    }

    private function clear_rolled_back_caches() {
        foreach (array_keys($this->transaction_user_ids) as $user_id) {
            wp_cache_delete($user_id, 'user_meta');
            clean_user_cache($user_id);
        }

        foreach (array_keys($this->transaction_post_ids) as $post_id) {
            clean_post_cache($post_id);
        }

        $this->transaction_user_ids = [];
        $this->transaction_post_ids = [];
    }

    private function log($level, $message, array $context = []) {
        if (function_exists('wc_get_logger')) {
            $context['source'] = 'rgv-loyalty';
            wc_get_logger()->log($level, $message, $context);
        }
    }

    /**
     * Merchandise only, after discounts, including its tax. Shipping and fees never earn points.
     */
    private function eligible_order_total($order) {
        $eligible = 0.0;

        foreach ($order->get_items('line_item') as $item) {
            $eligible += max(0, (float) $item->get_total() + (float) $item->get_total_tax());
        }

        return max(0, $eligible);
    }

    private function refund_merchandise_total($refund) {
        $line_total = 0.0;

        foreach ($refund->get_items('line_item') as $item) {
            $line_total += abs((float) $item->get_total() + (float) $item->get_total_tax());
        }

        if ($line_total > 0) {
            return $line_total;
        }

        // Manual amount-only refunds have no product lines. Exclude any explicit shipping and fee refunds.
        $shipping = 0.0;
        foreach ($refund->get_items('shipping') as $item) {
            $shipping += abs((float) $item->get_total() + (float) $item->get_total_tax());
        }

        $fees = 0.0;
        foreach ($refund->get_items('fee') as $item) {
            $fees += abs((float) $item->get_total() + (float) $item->get_total_tax());
        }

        return max(0, abs((float) $refund->get_total()) - $shipping - $fees);
    }

    private function refunded_merchandise_total($order) {
        $refunded = 0.0;

        foreach ($order->get_refunds() as $refund) {
            $refunded += $this->refund_merchandise_total($refund);
        }

        return min($this->eligible_order_total($order), max(0, $refunded));
    }

    private function target_order_points($order) {
        $settings = $this->settings();
        $eligible_statuses = ['completed'];

        if (!empty($settings['award_processing'])) {
            $eligible_statuses[] = 'processing';
        }

        if (!in_array($order->get_status(), $eligible_statuses, true)) {
            return 0;
        }

        $net_merchandise = max(0, $this->eligible_order_total($order) - $this->refunded_merchandise_total($order));
        return max(0, (int) floor($net_merchandise * (float) $settings['points_per_dollar']));
    }

    private function coupon_status($coupon) {
        $status = sanitize_key((string) $coupon->get_meta(self::COUPON_STATUS_META, true));

        if ($status) {
            return $status;
        }

        // Compatibility with coupons generated by version 1.0.0.
        if ($coupon->get_meta('_rgv_loyalty_restored', true)) {
            return self::COUPON_STATUS_RESTORED;
        }

        return self::COUPON_STATUS_ACTIVE;
    }

    private function invalidate_coupon_unlocked($coupon, $status, $reason, $order_id = 0) {
        if ($coupon->get_id()) {
            $this->transaction_post_ids[$coupon->get_id()] = true;
        }
        $coupon->update_meta_data(self::COUPON_STATUS_META, sanitize_key($status));
        $coupon->update_meta_data(self::COUPON_REVOKED_REASON_META, sanitize_text_field($reason));
        $coupon->set_date_expires(time() - DAY_IN_SECONDS);

        if ($status === self::COUPON_STATUS_RESTORED && $order_id) {
            $coupon->update_meta_data(self::COUPON_RESTORED_ORDER_META, absint($order_id));
            $coupon->update_meta_data('_rgv_loyalty_restored', 1);
        }

        $coupon->save();
    }

    private function customer_coupon_ids($user_id) {
        return get_posts([
            'post_type' => 'shop_coupon',
            'post_status' => ['publish', 'draft'],
            'posts_per_page' => -1,
            'fields' => 'ids',
            'orderby' => 'date',
            'order' => 'ASC',
            'no_found_rows' => true,
            'meta_query' => [
                [
                    'key' => self::COUPON_OWNER_META,
                    'value' => absint($user_id),
                    'compare' => '=',
                    'type' => 'NUMERIC',
                ],
            ],
        ]);
    }

    /**
     * Before creating loyalty debt, revoke unused active rewards and return their points.
     * Used rewards are never silently restored; their owner correctly keeps a negative balance.
     */
    private function reclaim_unspent_rewards_unlocked($user_id, $points_needed, $reason, $reference = '') {
        if (!class_exists('WC_Coupon') || $points_needed < 1) {
            return 0;
        }

        $reclaimed = 0;

        foreach ($this->customer_coupon_ids($user_id) as $coupon_id) {
            $coupon = new WC_Coupon($coupon_id);

            if ($this->coupon_status($coupon) !== self::COUPON_STATUS_ACTIVE) {
                continue;
            }

            if ((int) $coupon->get_usage_count() > 0) {
                continue;
            }

            $expires = $coupon->get_date_expires();
            if ($expires && $expires->getTimestamp() < time()) {
                continue;
            }

            $points = absint($coupon->get_meta(self::COUPON_POINTS_META, true));
            if ($points < 1) {
                continue;
            }

            $this->invalidate_coupon_unlocked(
                $coupon,
                self::COUPON_STATUS_REVOKED,
                $reason
            );

            $result = $this->transaction_unlocked(
                $user_id,
                $points,
                'coupon_revoked',
                sprintf(__('Unused reward %s was revoked and returned to points.', 'rgv-loyalty'), $coupon->get_code()),
                $reference ?: (string) $coupon_id,
                true
            );

            if (is_wp_error($result)) {
                throw new RuntimeException($result->get_error_message());
            }

            $reclaimed += $points;
            if ($reclaimed >= $points_needed) {
                break;
            }
        }

        return $reclaimed;
    }

    public function handle_order_status_changed($order_id, $from, $to, $order) {
        if (!$order instanceof WC_Order) {
            $order = wc_get_order($order_id);
        }

        if (!$order) {
            return;
        }

        $this->sync_order_points($order);

        if (in_array($to, ['processing', 'completed'], true)) {
            $this->mark_reward_coupons_used($order);
        }

        if (in_array($to, ['cancelled', 'failed', 'refunded'], true)) {
            $this->restore_reward_coupons($order, $to);
        }
    }

    public function handle_order_refunded($order_id, $refund_id) {
        $order = wc_get_order($order_id);
        $refund = wc_get_order($refund_id);

        if (!$order || !$refund) {
            return;
        }

        // This marker makes the refund event auditable and harmless if WooCommerce fires it again.
        if (!$refund->get_meta(self::REFUND_POINTS_META, true)) {
            $refund->update_meta_data(self::REFUND_POINTS_META, 'synced');
            $refund->save_meta_data();
        }

        $this->sync_order_points($order);

        $total = (float) $order->get_total();
        $refunded = abs((float) $order->get_total_refunded());
        if ($total > 0 && ($refunded + 0.01) >= $total) {
            $this->restore_reward_coupons($order, 'full_refund');
        }
    }

    private function sync_order_points($order) {
        if (!class_exists('WooCommerce') || !$order instanceof WC_Order || !$order->get_customer_id()) {
            return;
        }

        $user_id = absint($order->get_customer_id());
        $order_id = $order->get_id();

        $result = $this->with_user_lock($user_id, function () use ($user_id, $order, $order_id) {
            return $this->db_transaction(function () use ($user_id, $order, $order_id) {
                $order->read_meta_data(true);
                $current = (int) $order->get_meta(self::ORDER_POINTS_META, true);
                $target = $this->target_order_points($order);
                $delta = $target - $current;

                if ($delta === 0) {
                    return true;
                }

                if ($delta < 0) {
                    $this->reclaim_unspent_rewards_unlocked(
                        $user_id,
                        abs($delta),
                        sprintf('Points source order #%s was reduced or reversed.', $order->get_order_number()),
                        (string) $order_id
                    );
                }

                $type = $delta > 0 ? 'earn' : 'reversal';
                $description = $delta > 0
                    ? sprintf(__('Points earned on order #%s', 'rgv-loyalty'), $order->get_order_number())
                    : sprintf(__('Points reversed or adjusted for order #%s', 'rgv-loyalty'), $order->get_order_number());

                $transaction = $this->transaction_unlocked(
                    $user_id,
                    $delta,
                    $type,
                    $description,
                    (string) $order_id,
                    true
                );

                if (is_wp_error($transaction)) {
                    return $transaction;
                }

                $this->transaction_post_ids[$order_id] = true;
                $order->update_meta_data(self::ORDER_POINTS_META, $target);
                $order->save_meta_data();

                return true;
            });
        });

        if (is_wp_error($result)) {
            $this->log('error', 'Unable to synchronize loyalty points for an order.', [
                'order_id' => $order_id,
                'error' => $result->get_error_message(),
            ]);
        }
    }

    private function mark_reward_coupons_used($order) {
        foreach ($order->get_coupon_codes() as $code) {
            $coupon_id = wc_get_coupon_id_by_code($code);
            if (!$coupon_id) {
                continue;
            }

            $coupon = new WC_Coupon($coupon_id);
            $owner_id = absint($coupon->get_meta(self::COUPON_OWNER_META, true));

            if (!$owner_id || !in_array($this->coupon_status($coupon), [self::COUPON_STATUS_ACTIVE, self::COUPON_STATUS_USED], true)) {
                continue;
            }

            $result = $this->with_user_lock($owner_id, function () use ($coupon_id, $order) {
                return $this->db_transaction(function () use ($coupon_id, $order) {
                    $fresh_coupon = new WC_Coupon($coupon_id);
                    $status = $this->coupon_status($fresh_coupon);

                    if (!in_array($status, [self::COUPON_STATUS_ACTIVE, self::COUPON_STATUS_USED], true)) {
                        return true;
                    }

                    $this->transaction_post_ids[$coupon_id] = true;
                    $fresh_coupon->update_meta_data(self::COUPON_STATUS_META, self::COUPON_STATUS_USED);
                    $fresh_coupon->update_meta_data(self::COUPON_USED_ORDER_META, $order->get_id());
                    $fresh_coupon->save();
                    return true;
                });
            });

            if (is_wp_error($result)) {
                $this->log('error', 'Unable to mark a loyalty coupon as used.', [
                    'coupon_id' => $coupon_id,
                    'order_id' => $order->get_id(),
                    'error' => $result->get_error_message(),
                ]);
            }
        }
    }

    private function restore_reward_coupons($order, $reason) {
        foreach ($order->get_coupon_codes() as $code) {
            $coupon_id = wc_get_coupon_id_by_code($code);
            if (!$coupon_id) {
                continue;
            }

            $coupon = new WC_Coupon($coupon_id);
            $owner_id = absint($coupon->get_meta(self::COUPON_OWNER_META, true));
            $points = absint($coupon->get_meta(self::COUPON_POINTS_META, true));

            if (!$owner_id || !$points) {
                continue;
            }

            $result = $this->with_user_lock($owner_id, function () use ($coupon_id, $owner_id, $points, $order, $reason) {
                return $this->db_transaction(function () use ($coupon_id, $owner_id, $points, $order, $reason) {
                    $fresh_coupon = new WC_Coupon($coupon_id);
                    $status = $this->coupon_status($fresh_coupon);

                    if (in_array($status, [self::COUPON_STATUS_RESTORED, self::COUPON_STATUS_REVOKED], true)) {
                        return true;
                    }

                    $this->invalidate_coupon_unlocked(
                        $fresh_coupon,
                        self::COUPON_STATUS_RESTORED,
                        sprintf('Reward order #%s ended as %s.', $order->get_order_number(), sanitize_key($reason)),
                        $order->get_id()
                    );

                    return $this->transaction_unlocked(
                        $owner_id,
                        $points,
                        'restore',
                        sprintf(__('Reward restored from order #%s', 'rgv-loyalty'), $order->get_order_number()),
                        (string) $order->get_id(),
                        true
                    );
                });
            });

            if (is_wp_error($result)) {
                $this->log('error', 'Unable to restore a loyalty reward from an order.', [
                    'coupon_id' => $coupon_id,
                    'order_id' => $order->get_id(),
                    'error' => $result->get_error_message(),
                ]);
            }
        }
    }

    public function summary($user_id) {
        $settings = $this->settings();
        $points = $this->get_balance($user_id);
        $minimum = (int) $settings['minimum_points'];
        $block = (int) $settings['points_per_reward'];
        $reward = (float) $settings['reward_value'];
        $positive_points = max(0, $points);
        $redeemable_blocks = $positive_points >= $minimum ? (int) floor($positive_points / $block) : 0;

        return [
            'points' => $points,
            'has_debt' => $points < 0,
            'minimum_points' => $minimum,
            'points_per_reward' => $block,
            'reward_value' => $reward,
            'redeemable_points' => $redeemable_blocks * $block,
            'redeemable_credit' => $redeemable_blocks * $reward,
            'can_redeem' => $points >= $minimum && $redeemable_blocks > 0,
            'points_to_unlock' => $points < 0 ? abs($points) + $minimum : max(0, $minimum - $points),
            'progress' => $points < 0 ? 0 : min(100, round(($points / max(1, $minimum)) * 100, 1)),
            'history' => array_slice($this->history($user_id), 0, 25),
        ];
    }

    public function register_routes() {
        register_rest_route('rgv-portal/v1', '/loyalty/redeem', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'rest_redeem'],
            'permission_callback' => [$this, 'rest_permission'],
            'args' => [
                'points' => [
                    'required' => false,
                    'sanitize_callback' => 'absint',
                    'validate_callback' => function ($value) {
                        return $value === null || is_numeric($value);
                    },
                ],
            ],
        ]);
    }

    private function request_key($request) {
        return spl_object_hash($request);
    }

    private function authenticate_portal_customer($request) {
        if (function_exists('rgvp_secret_permission') && function_exists('rgvp_auth_user_from_request')) {
            $permission = rgvp_secret_permission($request);
            if (is_wp_error($permission)) {
                return $permission;
            }

            $auth = rgvp_auth_user_from_request($request);
            if (!$auth || empty($auth['user']) || !$auth['user'] instanceof WP_User) {
                return new WP_Error('loyalty_session', __('Your session has expired.', 'rgv-loyalty'), ['status' => 401]);
            }

            return $auth['user'];
        }

        // Backwards-compatible fallback for portal implementations that do not expose helper functions.
        $me = new WP_REST_Request('GET', '/rgv-portal/v1/me');
        foreach (['authorization', 'x-rgv-portal-secret'] as $header) {
            $value = $request->get_header($header);
            if ($value) {
                $me->set_header($header, $value);
            }
        }

        $response = rest_do_request($me);
        if ($response->is_error()) {
            return new WP_Error('loyalty_session', __('Your session has expired.', 'rgv-loyalty'), ['status' => 401]);
        }

        $data = $response->get_data();
        $user_data = is_array($data) ? ($data['user'] ?? []) : [];
        $user = !empty($user_data['id']) ? get_user_by('id', absint($user_data['id'])) : null;

        if (!$user && !empty($user_data['email'])) {
            $user = get_user_by('email', sanitize_email($user_data['email']));
        }

        return $user ?: new WP_Error('loyalty_customer', __('Customer account not found.', 'rgv-loyalty'), ['status' => 404]);
    }

    public function rest_permission($request) {
        $user = $this->authenticate_portal_customer($request);
        if (is_wp_error($user)) {
            return $user;
        }

        $this->request_users[$this->request_key($request)] = $user->ID;
        return true;
    }

    private function rest_customer($request) {
        $key = $this->request_key($request);
        $user_id = absint($this->request_users[$key] ?? 0);

        if ($user_id) {
            $user = get_user_by('id', $user_id);
            if ($user) {
                return $user;
            }
        }

        return $this->authenticate_portal_customer($request);
    }

    private function throttle_redemption($user_id) {
        $key = 'rgvl_redeem_' . absint($user_id);
        $attempts = (int) get_transient($key);

        if ($attempts >= 20) {
            return new WP_Error(
                'loyalty_rate_limit',
                __('Too many reward requests. Try again later.', 'rgv-loyalty'),
                ['status' => 429]
            );
        }

        set_transient($key, $attempts + 1, 10 * MINUTE_IN_SECONDS);
        return true;
    }

    private function idempotency_key($request) {
        $key = trim((string) $request->get_header('idempotency-key'));
        if (!$key || strlen($key) > 80 || !preg_match('/^[A-Za-z0-9._:-]+$/', $key)) {
            return '';
        }

        return hash('sha256', $key);
    }

    private function idempotency_records_unlocked($user_id) {
        $records = get_user_meta($user_id, self::IDEMPOTENCY_META, true);
        $records = is_array($records) ? $records : [];
        $cutoff = time() - DAY_IN_SECONDS;

        foreach ($records as $key => $record) {
            if (!is_array($record) || absint($record['created'] ?? 0) < $cutoff) {
                unset($records[$key]);
            }
        }

        return $records;
    }

    private function coupon_response($coupon, $user_id, $message = '') {
        $expires = $coupon->get_date_expires();

        return new WP_REST_Response([
            'success' => true,
            'message' => $message ?: __('Your store-credit code is ready.', 'rgv-loyalty'),
            'coupon' => $coupon->get_code(),
            'credit' => (float) $coupon->get_amount(),
            'expires' => $expires ? gmdate('Y-m-d', $expires->getTimestamp()) : null,
            'loyalty' => $this->summary($user_id),
        ], 200);
    }

    public function rest_redeem($request) {
        if (!class_exists('WooCommerce') || !class_exists('WC_Coupon')) {
            return new WP_Error('loyalty_woocommerce', __('WooCommerce is required.', 'rgv-loyalty'), ['status' => 503]);
        }

        $user = $this->rest_customer($request);
        if (is_wp_error($user)) {
            return $user;
        }

        $throttle = $this->throttle_redemption($user->ID);
        if (is_wp_error($throttle)) {
            return $throttle;
        }

        $requested = absint($request->get_param('points'));
        $idempotency_key = $this->idempotency_key($request);

        $result = $this->with_user_lock($user->ID, function () use ($user, $requested, $idempotency_key) {
            return $this->db_transaction(function () use ($user, $requested, $idempotency_key) {
                wp_cache_delete($user->ID, 'user_meta');

                $records = $this->idempotency_records_unlocked($user->ID);
                if ($idempotency_key && !empty($records[$idempotency_key]['coupon_id'])) {
                    $coupon = new WC_Coupon(absint($records[$idempotency_key]['coupon_id']));
                    $status = $this->coupon_status($coupon);

                    if (in_array($status, [self::COUPON_STATUS_ACTIVE, self::COUPON_STATUS_USED], true)) {
                        return [
                            'coupon_id' => $coupon->get_id(),
                            'replayed' => true,
                        ];
                    }

                    return new WP_Error(
                        'loyalty_idempotency_reused',
                        __('This reward request was already completed and can no longer be replayed.', 'rgv-loyalty'),
                        ['status' => 409]
                    );
                }

                $summary = $this->summary($user->ID);
                if (!$summary['can_redeem']) {
                    $message = $summary['has_debt']
                        ? __('Your rewards account has a negative balance and cannot redeem yet.', 'rgv-loyalty')
                        : sprintf(__('You need at least %d points to redeem.', 'rgv-loyalty'), $summary['minimum_points']);

                    return new WP_Error('loyalty_locked', $message, ['status' => 400]);
                }

                $points = $requested ?: (int) $summary['redeemable_points'];
                $block = (int) $summary['points_per_reward'];

                if (
                    $points < (int) $summary['minimum_points'] ||
                    $points % $block !== 0 ||
                    $points > (int) $summary['redeemable_points']
                ) {
                    return new WP_Error(
                        'loyalty_points',
                        __('Choose an available whole reward amount.', 'rgv-loyalty'),
                        ['status' => 400]
                    );
                }

                // Deduct first inside the transaction. A failure rolls back both balance and coupon.
                $transaction = $this->transaction_unlocked(
                    $user->ID,
                    -$points,
                    'redeem',
                    sprintf(__('Redeemed %d points for store credit.', 'rgv-loyalty'), $points),
                    '',
                    false
                );

                if (is_wp_error($transaction)) {
                    return $transaction;
                }

                $credit = ($points / $block) * (float) $summary['reward_value'];
                $code = $this->unique_coupon_code();
                $expiry_timestamp = strtotime('+' . absint($this->settings()['coupon_expiry_days']) . ' days');
                $redemption_id = wp_generate_uuid4();

                $coupon = new WC_Coupon();
                $coupon->set_code($code);
                $coupon->set_description(sprintf('RGV loyalty reward for user #%d. Redemption %s.', $user->ID, $redemption_id));
                $coupon->set_discount_type('fixed_cart');
                $coupon->set_amount(wc_format_decimal($credit));
                $coupon->set_usage_limit(1);
                $coupon->set_usage_limit_per_user(1);
                $coupon->set_individual_use(true);
                $coupon->set_email_restrictions([sanitize_email($user->user_email)]);
                $coupon->set_date_expires($expiry_timestamp);
                $coupon->add_meta_data(self::COUPON_OWNER_META, $user->ID, true);
                $coupon->add_meta_data(self::COUPON_POINTS_META, $points, true);
                $coupon->add_meta_data(self::COUPON_STATUS_META, self::COUPON_STATUS_ACTIVE, true);
                $coupon->add_meta_data(self::COUPON_REDEMPTION_META, $redemption_id, true);
                $coupon->add_meta_data(self::COUPON_CREATED_META, current_time('mysql', true), true);
                $coupon->save();

                if (!$coupon->get_id()) {
                    throw new RuntimeException('WooCommerce did not create the loyalty coupon.');
                }
                $this->transaction_post_ids[$coupon->get_id()] = true;

                // Attach the coupon ID to the newest redemption history item for auditability.
                $history = $this->history($user->ID);
                if (!empty($history[0]) && $history[0]['type'] === 'redeem' && empty($history[0]['reference'])) {
                    $history[0]['reference'] = (string) $coupon->get_id();
                    $this->transaction_user_ids[$user->ID] = true;
                    if (update_user_meta($user->ID, self::HISTORY_META, $history) === false) {
                        throw new RuntimeException('Unable to attach the coupon to the redemption history.');
                    }
                }

                if ($idempotency_key) {
                    $records[$idempotency_key] = [
                        'coupon_id' => $coupon->get_id(),
                        'created' => time(),
                    ];
                    $this->transaction_user_ids[$user->ID] = true;
                    if (update_user_meta($user->ID, self::IDEMPOTENCY_META, array_slice($records, -50, null, true)) === false) {
                        throw new RuntimeException('Unable to persist the redemption idempotency record.');
                    }
                }

                return [
                    'coupon_id' => $coupon->get_id(),
                    'replayed' => false,
                ];
            });
        });

        if (is_wp_error($result)) {
            return $result;
        }

        $coupon = new WC_Coupon(absint($result['coupon_id'] ?? 0));
        if (!$coupon->get_id()) {
            return new WP_Error(
                'loyalty_coupon_missing',
                __('The reward was created but could not be loaded. Contact support.', 'rgv-loyalty'),
                ['status' => 500]
            );
        }

        return $this->coupon_response(
            $coupon,
            $user->ID,
            !empty($result['replayed'])
                ? __('This request was already completed. The original code is shown again.', 'rgv-loyalty')
                : __('Your store-credit code is ready.', 'rgv-loyalty')
        );
    }

    private function unique_coupon_code() {
        for ($attempt = 0; $attempt < 10; $attempt++) {
            $code = 'LOYALTY-' . strtoupper(wp_generate_password(18, false, false));
            if (!wc_get_coupon_id_by_code($code)) {
                return $code;
            }
        }

        throw new RuntimeException('Unable to generate a unique loyalty coupon code.');
    }

    /**
     * Extra ownership and fraud checks beyond WooCommerce's email restriction.
     */
    public function validate_loyalty_coupon($valid, $coupon, $discounts = null) {
        if (!$valid || !$coupon instanceof WC_Coupon) {
            return $valid;
        }

        $owner_id = absint($coupon->get_meta(self::COUPON_OWNER_META, true));
        if (!$owner_id) {
            return $valid;
        }

        $status = $this->coupon_status($coupon);
        if (in_array($status, [self::COUPON_STATUS_REVOKED, self::COUPON_STATUS_RESTORED], true)) {
            return false;
        }

        if ($this->get_balance($owner_id) < 0) {
            return false;
        }

        $current_user_id = get_current_user_id();
        $checkout_user_id = 0;
        $billing_email = '';

        // Prefer the customer attached to WooCommerce's discount context. This also
        // works for headless checkout requests when there is no WordPress login cookie.
        if (is_object($discounts) && method_exists($discounts, 'get_customer')) {
            $discount_customer = $discounts->get_customer();
            if (is_object($discount_customer)) {
                if (method_exists($discount_customer, 'get_id')) {
                    $checkout_user_id = absint($discount_customer->get_id());
                }
                if (method_exists($discount_customer, 'get_billing_email')) {
                    $billing_email = strtolower(sanitize_email((string) $discount_customer->get_billing_email()));
                }
            }
        }

        if (function_exists('WC') && WC()->customer) {
            if (!$checkout_user_id && method_exists(WC()->customer, 'get_id')) {
                $checkout_user_id = absint(WC()->customer->get_id());
            }
            if (!$billing_email && method_exists(WC()->customer, 'get_billing_email')) {
                $billing_email = strtolower(sanitize_email((string) WC()->customer->get_billing_email()));
            }
        }

        $known_user_id = $current_user_id ?: $checkout_user_id;
        if ($known_user_id && $known_user_id !== $owner_id) {
            return false;
        }

        $owner = get_user_by('id', $owner_id);
        $owner_email = $owner ? strtolower(sanitize_email((string) $owner->user_email)) : '';

        if ($billing_email && $owner_email && !hash_equals($owner_email, $billing_email)) {
            return false;
        }

        return true;
    }

    public function add_loyalty_to_portal_response($response, $server, $request) {
        if (!in_array($request->get_route(), [
            '/rgv-portal/v1/me',
            '/rgv-portal/v1/login',
            '/rgv-portal/v1/register',
        ], true) || is_wp_error($response) || !is_object($response) || !method_exists($response, 'get_data')) {
            return $response;
        }

        $data = $response->get_data();
        if (!is_array($data) || empty($data['user'])) {
            return $response;
        }

        $user_id = absint($data['user']['id'] ?? 0);
        if (!$user_id && !empty($data['user']['email'])) {
            $user = get_user_by('email', sanitize_email($data['user']['email']));
            $user_id = $user ? $user->ID : 0;
        }

        if ($user_id) {
            $data['user']['loyalty'] = $this->summary($user_id);
            $data['loyalty'] = $data['user']['loyalty'];
            $response->set_data($data);
        }

        return $response;
    }

    public function admin_menu() {
        if (!class_exists('WooCommerce')) {
            return;
        }

        add_submenu_page(
            'woocommerce',
            __('RGV Loyalty Program', 'rgv-loyalty'),
            __('Loyalty Program', 'rgv-loyalty'),
            'manage_woocommerce',
            'rgv-loyalty',
            [$this, 'admin_page']
        );
    }

    public function user_column($columns) {
        $columns['rgv_loyalty'] = __('Loyalty points', 'rgv-loyalty');
        return $columns;
    }

    public function user_column_value($value, $column, $user_id) {
        if ($column !== 'rgv_loyalty') {
            return $value;
        }

        $balance = $this->get_balance($user_id);
        $style = $balance < 0 ? ' style="color:#b32d2e;font-weight:700"' : '';
        return '<span' . $style . '>' . esc_html(number_format_i18n($balance)) . '</span>';
    }

    public function admin_adjust() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('Access denied.', 'rgv-loyalty'));
        }

        check_admin_referer('rgv_loyalty_adjust');

        $user_id = absint($_POST['user_id'] ?? 0);
        $points = (int) ($_POST['points'] ?? 0);
        $points = max(-10000000, min(10000000, $points));
        $note = sanitize_text_field(wp_unslash($_POST['note'] ?? 'Manual adjustment'));

        if ($user_id && $points) {
            $result = $this->with_user_lock($user_id, function () use ($user_id, $points, $note) {
                return $this->db_transaction(function () use ($user_id, $points, $note) {
                    if ($points < 0) {
                        $this->reclaim_unspent_rewards_unlocked(
                            $user_id,
                            abs($points),
                            'An administrator reduced the customer loyalty balance.',
                            'admin:' . get_current_user_id()
                        );
                    }

                    return $this->transaction_unlocked(
                        $user_id,
                        $points,
                        'adjustment',
                        $note,
                        'admin:' . get_current_user_id(),
                        true
                    );
                });
            });

            if (is_wp_error($result)) {
                wp_safe_redirect(add_query_arg([
                    'page' => 'rgv-loyalty',
                    'rgv_error' => rawurlencode($result->get_error_message()),
                ], admin_url('admin.php')));
                exit;
            }
        }

        wp_safe_redirect(add_query_arg([
            'page' => 'rgv-loyalty',
            'updated' => 1,
        ], admin_url('admin.php')));
        exit;
    }

    public function admin_page() {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }

        $settings = $this->settings();
        $search = sanitize_text_field(wp_unslash($_GET['s'] ?? ''));
        $paged = max(1, absint($_GET['paged'] ?? 1));
        $per_page = 50;

        $args = [
            'number' => $per_page,
            'paged' => $paged,
            'orderby' => 'registered',
            'order' => 'DESC',
            'count_total' => true,
            'role__in' => ['customer', 'subscriber'],
        ];

        if ($search) {
            $args['search'] = '*' . $search . '*';
            $args['search_columns'] = ['user_login', 'user_email', 'display_name'];
        }

        $query = new WP_User_Query($args);
        $users = $query->get_results();
        $total = (int) $query->get_total();
        $total_pages = max(1, (int) ceil($total / $per_page));
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('RGV Loyalty Program', 'rgv-loyalty'); ?></h1>

            <?php if (!empty($_GET['updated'])): ?>
                <div class="notice notice-success is-dismissible"><p><?php esc_html_e('Loyalty settings or balance updated.', 'rgv-loyalty'); ?></p></div>
            <?php endif; ?>

            <?php if (!empty($_GET['rgv_error'])): ?>
                <div class="notice notice-error"><p><?php echo esc_html(rawurldecode(wp_unslash($_GET['rgv_error']))); ?></p></div>
            <?php endif; ?>

            <p><?php esc_html_e('Points are calculated from paid merchandise after discounts. Shipping and fees never earn points.', 'rgv-loyalty'); ?></p>
            <p><strong><?php esc_html_e('Fraud protection:', 'rgv-loyalty'); ?></strong> <?php esc_html_e('Refunds and reversals may create a negative balance when a reward was already used. Unused reward coupons are revoked automatically.', 'rgv-loyalty'); ?></p>

            <div style="display:grid;grid-template-columns:minmax(300px,520px) minmax(600px,1fr);gap:24px;align-items:start">
                <div class="card" style="max-width:none">
                    <h2><?php esc_html_e('Program settings', 'rgv-loyalty'); ?></h2>
                    <form method="post" action="options.php">
                        <?php settings_fields('rgv_loyalty'); ?>
                        <table class="form-table"><tbody>
                            <tr>
                                <th><label for="ppd"><?php esc_html_e('Points per currency unit', 'rgv-loyalty'); ?></label></th>
                                <td><input id="ppd" type="number" min="0.0001" max="1000" step="0.0001" name="<?php echo esc_attr(self::OPTION); ?>[points_per_dollar]" value="<?php echo esc_attr($settings['points_per_dollar']); ?>"></td>
                            </tr>
                            <tr>
                                <th><label for="minimum"><?php esc_html_e('Minimum points to unlock', 'rgv-loyalty'); ?></label></th>
                                <td><input id="minimum" type="number" min="1" step="1" name="<?php echo esc_attr(self::OPTION); ?>[minimum_points]" value="<?php echo esc_attr($settings['minimum_points']); ?>"><p class="description"><?php esc_html_e('Saved as a whole multiple of “Points per reward”.', 'rgv-loyalty'); ?></p></td>
                            </tr>
                            <tr>
                                <th><label for="block"><?php esc_html_e('Points per reward', 'rgv-loyalty'); ?></label></th>
                                <td><input id="block" type="number" min="1" step="1" name="<?php echo esc_attr(self::OPTION); ?>[points_per_reward]" value="<?php echo esc_attr($settings['points_per_reward']); ?>"></td>
                            </tr>
                            <tr>
                                <th><label for="value"><?php esc_html_e('Credit per reward', 'rgv-loyalty'); ?></label></th>
                                <td><input id="value" type="number" min="0.01" step="0.01" name="<?php echo esc_attr(self::OPTION); ?>[reward_value]" value="<?php echo esc_attr($settings['reward_value']); ?>"> <code><?php echo esc_html(get_woocommerce_currency()); ?></code></td>
                            </tr>
                            <tr>
                                <th><label for="expiry"><?php esc_html_e('Coupon expiration (days)', 'rgv-loyalty'); ?></label></th>
                                <td><input id="expiry" type="number" min="1" max="3650" step="1" name="<?php echo esc_attr(self::OPTION); ?>[coupon_expiry_days]" value="<?php echo esc_attr($settings['coupon_expiry_days']); ?>"></td>
                            </tr>
                            <tr>
                                <th><?php esc_html_e('Award timing', 'rgv-loyalty'); ?></th>
                                <td><label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[award_processing]" value="1" <?php checked($settings['award_processing']); ?>> <?php esc_html_e('Award at Processing; otherwise award only at Completed.', 'rgv-loyalty'); ?></label></td>
                            </tr>
                        </tbody></table>
                        <?php submit_button(); ?>
                    </form>
                </div>

                <div>
                    <form method="get">
                        <input type="hidden" name="page" value="rgv-loyalty">
                        <p class="search-box">
                            <label class="screen-reader-text" for="loyalty-search"><?php esc_html_e('Search customers', 'rgv-loyalty'); ?></label>
                            <input id="loyalty-search" type="search" name="s" value="<?php echo esc_attr($search); ?>">
                            <input type="submit" class="button" value="<?php esc_attr_e('Search customers', 'rgv-loyalty'); ?>">
                        </p>
                    </form>

                    <table class="widefat striped">
                        <thead><tr>
                            <th><?php esc_html_e('Customer', 'rgv-loyalty'); ?></th>
                            <th><?php esc_html_e('Email', 'rgv-loyalty'); ?></th>
                            <th><?php esc_html_e('Points', 'rgv-loyalty'); ?></th>
                            <th><?php esc_html_e('Redeemable credit', 'rgv-loyalty'); ?></th>
                            <th><?php esc_html_e('Adjustment', 'rgv-loyalty'); ?></th>
                        </tr></thead>
                        <tbody>
                        <?php if (!$users): ?>
                            <tr><td colspan="5"><?php esc_html_e('No customers found.', 'rgv-loyalty'); ?></td></tr>
                        <?php endif; ?>

                        <?php foreach ($users as $user): $summary = $this->summary($user->ID); ?>
                            <tr>
                                <td><strong><?php echo esc_html($user->display_name); ?></strong></td>
                                <td><?php echo esc_html($user->user_email); ?></td>
                                <td>
                                    <span style="<?php echo $summary['points'] < 0 ? 'color:#b32d2e;font-weight:700' : ''; ?>">
                                        <?php echo esc_html(number_format_i18n($summary['points'])); ?>
                                    </span>
                                </td>
                                <td><?php echo wp_kses_post(wc_price($summary['redeemable_credit'])); ?></td>
                                <td>
                                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:flex;gap:5px;flex-wrap:wrap">
                                        <input type="hidden" name="action" value="rgv_loyalty_adjust">
                                        <input type="hidden" name="user_id" value="<?php echo esc_attr($user->ID); ?>">
                                        <?php wp_nonce_field('rgv_loyalty_adjust'); ?>
                                        <input type="number" name="points" required placeholder="+/- points" style="width:105px">
                                        <input type="text" name="note" required maxlength="180" placeholder="Reason" style="width:150px">
                                        <button class="button"><?php esc_html_e('Apply', 'rgv-loyalty'); ?></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>

                    <?php if ($total_pages > 1): ?>
                        <div class="tablenav"><div class="tablenav-pages" style="margin:12px 0">
                            <?php
                            echo wp_kses_post(paginate_links([
                                'base' => add_query_arg([
                                    'page' => 'rgv-loyalty',
                                    's' => $search,
                                    'paged' => '%#%',
                                ], admin_url('admin.php')),
                                'format' => '',
                                'current' => $paged,
                                'total' => $total_pages,
                                'prev_text' => '&lsaquo;',
                                'next_text' => '&rsaquo;',
                            ]));
                            ?>
                        </div></div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }
}

register_activation_hook(__FILE__, ['RGV_Loyalty_Program', 'activate']);
add_action('plugins_loaded', ['RGV_Loyalty_Program', 'boot']);

add_action('before_woocommerce_init', function () {
    if (class_exists('Automattic\\WooCommerce\\Utilities\\FeaturesUtil')) {
        Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
            'custom_order_tables',
            __FILE__,
            true
        );
    }
});
