RGVPRIME TAGADAPAY CHECKOUT PLUGIN

Contenido:
- plugin.manifest.json
- config/rgvprime-checkout.config.json
- config/schema.json
- config/ui-schema.json
- dist/index.html

Branding aplicado:
- RGVPRIME LLC
- sales@rgvprimellc.com
- negro / rojo / blanco
- nada de RGVPRIMER
- nada de Info@rgvprimellc.com

Cómo subirlo:
1. Descomprime este ZIP.
2. Abre terminal dentro de la carpeta rgvprime-tagada-checkout.
3. Instala la CLI:
   npm install -g @tagadapay/plugin-cli@^3.0.0
4. Ejecuta:
   tgdcli deploy
5. Selecciona tu tienda.
6. Si Tagada te muestra presets/configuración, selecciona: rgvprime-checkout.config.json

Nota:
Este paquete está armado con el manifest y el JSON visual que compartiste. Si Tagada exige algún entry JS específico del SDK, pásame el error del deploy y lo ajustamos exacto.
